import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-dtl',
  templateUrl: './project-dtl.component.html',
  styleUrls: ['./project-dtl.component.css']
})
export class ProjectDtlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
