export class MasterPages{
    masterId:string;
    masterDescription:string;
    constructor(  masterId:string,   masterDescription:string){
        this.masterId= masterId;
        this.masterDescription = masterDescription;
    }
}
