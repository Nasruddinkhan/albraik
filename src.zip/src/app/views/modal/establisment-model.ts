import { ProjectModel } from './project-model';

export class Establisement{
    project: ProjectModel;
    projectDetailsId:number;
    companyName:string;
}

