import { ProjectModel } from './project-model';

export class InheritanceModel{
    project:ProjectModel;
    projectDetailsId:string;
    inheritanceOwnerId:string;
}