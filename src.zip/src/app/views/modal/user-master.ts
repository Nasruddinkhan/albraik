export class UserMaster{
    email : string;
    name:string
    joiningDate: Date;
    id:number
    
}